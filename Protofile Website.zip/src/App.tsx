import { useState, useEffect } from "react";

const NAV_LINKS = [
  { label: "About", href: "#about" },
  { label: "Education", href: "#education" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Experience", href: "#experience" },
  { label: "Certifications", href: "#certifications" },
];

const SKILLS = {
  Languages: ["Java", "C", "C++"],
  Web: ["HTML", "CSS", "MySQL"],
  Tools: ["Git", "VS Code"],
  Concepts: ["OOP", "DBMS", "Operating Systems"],
  "Soft Skills": ["Time Management", "Leadership", "Quick Learner"],
};

const SKILL_COLORS: Record<string, string> = {
  Java: "bg-orange-100 text-orange-700 border-orange-200",
  C: "bg-blue-100 text-blue-700 border-blue-200",
  "C++": "bg-indigo-100 text-indigo-700 border-indigo-200",
  HTML: "bg-red-100 text-red-700 border-red-200",
  CSS: "bg-sky-100 text-sky-700 border-sky-200",
  MySQL: "bg-teal-100 text-teal-700 border-teal-200",
  Git: "bg-rose-100 text-rose-700 border-rose-200",
  "VS Code": "bg-blue-100 text-blue-700 border-blue-200",
  OOP: "bg-purple-100 text-purple-700 border-purple-200",
  DBMS: "bg-green-100 text-green-700 border-green-200",
  "Operating Systems": "bg-yellow-100 text-yellow-700 border-yellow-200",
  "Time Management": "bg-pink-100 text-pink-700 border-pink-200",
  Leadership: "bg-violet-100 text-violet-700 border-violet-200",
  "Quick Learner": "bg-emerald-100 text-emerald-700 border-emerald-200",
};

export default function App() {
  const [activeSection, setActiveSection] = useState("about");
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      const sections = NAV_LINKS.map((l) => l.href.replace("#", ""));
      for (const section of [...sections].reverse()) {
        const el = document.getElementById(section);
        if (el && window.scrollY >= el.offsetTop - 120) {
          setActiveSection(section);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-['Inter',sans-serif]">
      {/* Animated background */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-violet-600 rounded-full opacity-10 blur-3xl animate-pulse" />
        <div className="absolute top-1/2 -left-40 w-80 h-80 bg-cyan-500 rounded-full opacity-10 blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
        <div className="absolute bottom-0 right-1/3 w-72 h-72 bg-fuchsia-600 rounded-full opacity-10 blur-3xl animate-pulse" style={{ animationDelay: "2s" }} />
      </div>

      {/* Navbar */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "bg-gray-950/90 backdrop-blur-md shadow-lg shadow-black/20 border-b border-gray-800/50" : "bg-transparent"}`}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
          <span className="text-lg font-bold bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent tracking-wide">
            KS
          </span>
          {/* Desktop Nav */}
          <ul className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    activeSection === link.href.replace("#", "")
                      ? "text-violet-400 bg-violet-500/10"
                      : "text-gray-400 hover:text-gray-100 hover:bg-gray-800/50"
                  }`}
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="mailto:krishnakantsilawat2006@gmail.com"
                className="ml-2 px-4 py-2 rounded-lg text-sm font-semibold bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white transition-all duration-200"
              >
                Contact
              </a>
            </li>
          </ul>
          {/* Mobile toggle */}
          <button
            className="md:hidden text-gray-300 hover:text-white p-2"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <div className={`w-6 h-0.5 bg-current transition-all duration-200 ${menuOpen ? "rotate-45 translate-y-1.5" : ""}`} />
            <div className={`w-6 h-0.5 bg-current mt-1.5 transition-all duration-200 ${menuOpen ? "opacity-0" : ""}`} />
            <div className={`w-6 h-0.5 bg-current mt-1.5 transition-all duration-200 ${menuOpen ? "-rotate-45 -translate-y-3" : ""}`} />
          </button>
        </div>
        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden bg-gray-900/95 backdrop-blur-md border-b border-gray-800 px-4 pb-4">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="block py-3 text-sm text-gray-300 hover:text-violet-400 border-b border-gray-800/50 last:border-0"
              >
                {link.label}
              </a>
            ))}
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="about" className="relative z-10 min-h-screen flex items-center pt-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 w-full py-20">
          <div className="flex flex-col md:flex-row items-center gap-12">
            {/* Avatar */}
            <div className="flex-shrink-0">
              <div className="relative">
                <div className="w-40 h-40 rounded-full bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-500 p-1 shadow-2xl shadow-violet-500/30">
                  <div className="w-full h-full rounded-full bg-gray-900 flex items-center justify-center">
                    <span className="text-5xl font-bold bg-gradient-to-br from-violet-400 to-cyan-400 bg-clip-text text-transparent">
                      KS
                    </span>
                  </div>
                </div>
                <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full border-4 border-gray-950 flex items-center justify-center">
                  <div className="w-2.5 h-2.5 bg-green-300 rounded-full animate-ping" />
                </div>
              </div>
            </div>
            {/* Info */}
            <div className="text-center md:text-left">
              <p className="text-violet-400 font-mono text-sm mb-2 tracking-widest uppercase">Hello, I'm</p>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight mb-3">
                <span className="bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
                  Krishankant
                </span>
                <br />
                <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                  Silawat
                </span>
              </h1>
              <p className="text-gray-400 text-lg mb-6 max-w-xl">
                Computer Science Student &amp; Full Stack Developer passionate about building scalable applications and learning modern technologies.
              </p>
              {/* Contact badges */}
              <div className="flex flex-wrap justify-center md:justify-start gap-3 mb-8 text-sm">
                <a href="tel:+916264095722" className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gray-800/70 border border-gray-700 text-gray-300 hover:border-violet-500 hover:text-violet-400 transition-all">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                  +91 6264095722
                </a>
                <a href="mailto:krishnakantsilawat2006@gmail.com" className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gray-800/70 border border-gray-700 text-gray-300 hover:border-violet-500 hover:text-violet-400 transition-all">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                  Gmail
                </a>
                <span className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gray-800/70 border border-gray-700 text-gray-300">
                  <svg className="w-4 h-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                  Vidisha, Madhya Pradesh
                </span>
              </div>
              {/* Social links */}
              <div className="flex flex-wrap justify-center md:justify-start gap-3">
                <a href="https://www.linkedin.com/in/krishankantsilawat18/" target="_blank" rel="noreferrer"
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-400 hover:bg-blue-600/30 hover:border-blue-400 transition-all font-medium text-sm">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                  LinkedIn ↗
                </a>
                <a href="https://github.com/KrishankantSilawat" target="_blank" rel="noreferrer"
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gray-700/50 border border-gray-600/50 text-gray-300 hover:bg-gray-700 hover:border-gray-500 transition-all font-medium text-sm">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z"/></svg>
                  GitHub
                </a>
                <a href="https://leetcode.com/u/KrishankantSilawat/" target="_blank" rel="noreferrer"
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/20 hover:border-yellow-400 transition-all font-medium text-sm">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M13.483 0a1.374 1.374 0 0 0-.961.438L7.116 6.226l-3.854 4.126a5.266 5.266 0 0 0-1.209 2.104 5.35 5.35 0 0 0-.125.513 5.527 5.527 0 0 0 .062 2.362 5.83 5.83 0 0 0 .349 1.017 5.938 5.938 0 0 0 1.271 1.818l4.277 4.193.039.038c2.248 2.165 5.852 2.133 8.063-.074l2.396-2.392c.54-.54.54-1.414.003-1.955a1.378 1.378 0 0 0-1.951-.003l-2.396 2.392a3.021 3.021 0 0 1-4.205.038l-.02-.019-4.276-4.193c-.652-.64-.972-1.469-.948-2.263a2.68 2.68 0 0 1 .066-.523 2.545 2.545 0 0 1 .619-1.164L9.13 8.114c1.058-1.134 3.204-1.27 4.43-.278l3.501 2.831c.593.48 1.461.387 1.94-.207a1.384 1.384 0 0 0-.207-1.943l-3.5-2.831c-.8-.647-1.766-1.045-2.774-1.202l2.015-2.158A1.384 1.384 0 0 0 13.483 0zm-2.866 12.815a1.38 1.38 0 0 0-1.38 1.382 1.38 1.38 0 0 0 1.38 1.382H20.79a1.38 1.38 0 0 0 1.38-1.382 1.38 1.38 0 0 0-1.38-1.382z"/></svg>
                  LeetCode
                </a>
              </div>
            </div>
          </div>

          {/* Summary card */}
          <div className="mt-16 relative">
            <div className="absolute inset-0 bg-gradient-to-r from-violet-600/20 to-cyan-600/20 rounded-2xl blur-xl" />
            <div className="relative bg-gray-900/60 backdrop-blur border border-gray-700/50 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-violet-500/20 flex items-center justify-center">
                  <svg className="w-4 h-4 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                </div>
                <h2 className="text-lg font-bold text-white uppercase tracking-widest text-sm">Professional Summary</h2>
              </div>
              <p className="text-gray-300 leading-relaxed text-base">
                Highly motivated <span className="text-violet-400 font-medium">Computer Science student</span> with strong problem-solving skills and hands-on experience in programming and web development. Passionate about building <span className="text-cyan-400 font-medium">scalable applications</span> and continuously learning modern technologies.
              </p>
            </div>
          </div>

          {/* Scroll indicator */}
          <div className="flex justify-center mt-16 animate-bounce">
            <a href="#education" className="text-gray-500 hover:text-violet-400 transition-colors">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
            </a>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="relative z-10 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <SectionHeader icon="🎓" title="Education" />
          <div className="space-y-6 mt-10">
            {[
              {
                degree: "Btech in Computer Science Engineering",
                institution: "Lakshmi Narain College Of Technology, Bhopal",
                year: "2023 – 2027",
                score: "CGPA: 7.03",
                scoreColor: "text-violet-400",
                icon: "🏛️",
              },
              {
                degree: "Higher Secondary Education",
                institution: "MP BOARD",
                year: "2023",
                score: "66%",
                scoreColor: "text-cyan-400",
                icon: "📚",
              },
              {
                degree: "Secondary Education",
                institution: "MP BOARD",
                year: "2021",
                score: "81%",
                scoreColor: "text-emerald-400",
                icon: "📖",
              },
            ].map((edu, i) => (
              <div key={i} className="group relative bg-gray-900/60 backdrop-blur border border-gray-700/50 rounded-2xl p-6 hover:border-violet-500/50 transition-all duration-300">
                <div className="absolute inset-0 bg-gradient-to-r from-violet-600/5 to-cyan-600/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <span className="text-2xl mt-1">{edu.icon}</span>
                    <div>
                      <h3 className="font-bold text-white text-lg">{edu.degree}</h3>
                      <p className="text-gray-400 mt-1">{edu.institution}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-start sm:items-end gap-1 sm:flex-shrink-0">
                    <span className="text-sm text-gray-400 font-mono bg-gray-800/80 px-3 py-1 rounded-full border border-gray-700">{edu.year}</span>
                    <span className={`font-bold text-lg ${edu.scoreColor}`}>{edu.score}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="relative z-10 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <SectionHeader icon="⚡" title="Technical Skills" />
          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(SKILLS).map(([category, skills]) => (
              <div key={category} className="bg-gray-900/60 backdrop-blur border border-gray-700/50 rounded-2xl p-6 hover:border-violet-500/30 transition-all">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-violet-500 inline-block" />
                  {category}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill) => (
                    <span
                      key={skill}
                      className={`px-3 py-1.5 rounded-lg text-sm font-medium border ${SKILL_COLORS[skill] || "bg-gray-800 text-gray-300 border-gray-700"}`}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="relative z-10 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <SectionHeader icon="🚀" title="Projects" />
          <div className="mt-10">
            <div className="group relative bg-gray-900/60 backdrop-blur border border-gray-700/50 rounded-2xl p-6 md:p-8 hover:border-violet-500/50 transition-all duration-300">
              <div className="absolute inset-0 bg-gradient-to-br from-violet-600/5 to-cyan-600/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-2xl">🛒</span>
                    <h3 className="text-xl font-bold text-white">Ink and Page E-Commerce Website</h3>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {["Node.js", "Express", "JWT", "Redis", "React", "Tailwind CSS"].map((tech) => (
                      <span key={tech} className="px-2.5 py-1 text-xs font-medium rounded-full bg-violet-500/15 text-violet-300 border border-violet-500/25">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-green-400 text-sm font-medium">Completed</span>
                </div>
              </div>
              <ul className="space-y-3">
                {[
                  "Built a secure web application using Node.js and Express with JWT authentication and RBAC.",
                  "Integrated Redis caching to reduce API latency by 40%.",
                  "Developed responsive frontend using React and Tailwind CSS.",
                ].map((point, i) => (
                  <li key={i} className="flex items-start gap-3 text-gray-300">
                    <span className="mt-2 w-1.5 h-1.5 rounded-full bg-cyan-400 flex-shrink-0" />
                    {point}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="relative z-10 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <SectionHeader icon="💼" title="Experience" />
          <div className="mt-10 space-y-6">
            {[
              {
                role: "Java Programming Internship",
                company: "CodeAlpha",
                period: "Sept 2025",
                description: "Completed virtual internship and gained hands-on experience in Java programming and real-world development practices.",
                color: "from-orange-500/20 to-red-500/20",
                border: "border-orange-500/30",
                badge: "bg-orange-500/15 text-orange-300 border-orange-500/25",
                icon: "☕",
              },
              {
                role: "Web Developer Intern",
                company: "Codec Technologies",
                period: "May 2026 – June 2026",
                description: "Worked as a Web Developer Intern at Codec Technologies, contributing to web application development and project-based learning.",
                color: "from-blue-500/20 to-cyan-500/20",
                border: "border-blue-500/30",
                badge: "bg-blue-500/15 text-blue-300 border-blue-500/25",
                icon: "🌐",
              },
            ].map((exp, i) => (
              <div key={i} className={`group relative bg-gray-900/60 backdrop-blur border ${exp.border} rounded-2xl p-6 md:p-8 hover:scale-[1.01] transition-all duration-300`}>
                <div className={`absolute inset-0 bg-gradient-to-r ${exp.color} rounded-2xl opacity-30 group-hover:opacity-50 transition-opacity`} />
                <div className="relative flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <span className="text-2xl">{exp.icon}</span>
                    <div>
                      <h3 className="text-lg font-bold text-white">{exp.role}</h3>
                      <span className={`inline-block mt-1 px-3 py-0.5 text-sm font-medium rounded-full border ${exp.badge}`}>
                        {exp.company}
                      </span>
                      <p className="mt-3 text-gray-300 leading-relaxed">{exp.description}</p>
                    </div>
                  </div>
                  <div className="flex-shrink-0">
                    <span className="text-sm text-gray-400 font-mono bg-gray-800/80 px-3 py-1 rounded-full border border-gray-700 whitespace-nowrap">
                      {exp.period}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section id="certifications" className="relative z-10 py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <SectionHeader icon="🏆" title="Certifications" />
          <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              {
                title: "Data Structures and Algorithms using Java",
                issuer: "Infosys Springboard",
                icon: "🧮",
                color: "border-purple-500/30 hover:border-purple-400/60",
                badge: "bg-purple-500/10 text-purple-300",
              },
              {
                title: "Web Design & Development",
                issuer: "Skill India Digital Hub",
                icon: "🎨",
                color: "border-pink-500/30 hover:border-pink-400/60",
                badge: "bg-pink-500/10 text-pink-300",
              },
              {
                title: "Introduction to Modern AI",
                issuer: "Cisco Network Academy",
                icon: "🤖",
                color: "border-cyan-500/30 hover:border-cyan-400/60",
                badge: "bg-cyan-500/10 text-cyan-300",
              },
              {
                title: "Full Stack Developer CI/CD",
                issuer: "Infosys Springboard",
                icon: "⚙️",
                color: "border-emerald-500/30 hover:border-emerald-400/60",
                badge: "bg-emerald-500/10 text-emerald-300",
              },
            ].map((cert, i) => (
              <div key={i} className={`group relative bg-gray-900/60 backdrop-blur border ${cert.color} rounded-2xl p-5 transition-all duration-300 hover:scale-[1.02]`}>
                <div className="flex items-start gap-4">
                  <span className="text-3xl">{cert.icon}</span>
                  <div>
                    <h3 className="font-semibold text-white leading-tight">{cert.title}</h3>
                    <span className={`inline-block mt-2 px-2.5 py-0.5 text-xs font-medium rounded-full ${cert.badge}`}>
                      {cert.issuer}
                    </span>
                  </div>
                </div>
                <div className="absolute top-4 right-4">
                  <svg className="w-4 h-4 text-gray-600 group-hover:text-gray-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                  </svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-gray-800/50 py-10 mt-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <p className="text-2xl font-bold bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent mb-2">
            Krishankant Silawat
          </p>
          <p className="text-gray-500 text-sm mb-6">Computer Science Student • Full Stack Developer</p>
          <div className="flex justify-center gap-4 mb-6">
            <a href="https://www.linkedin.com/in/krishankantsilawat18/" target="_blank" rel="noreferrer" className="text-gray-500 hover:text-blue-400 transition-colors">LinkedIn</a>
            <span className="text-gray-700">•</span>
            <a href="https://github.com/KrishankantSilawat" target="_blank" rel="noreferrer" className="text-gray-500 hover:text-gray-200 transition-colors">GitHub</a>
            <span className="text-gray-700">•</span>
            <a href="https://leetcode.com/u/KrishankantSilawat/" target="_blank" rel="noreferrer" className="text-gray-500 hover:text-yellow-400 transition-colors">LeetCode</a>
            <span className="text-gray-700">•</span>
            <a href="mailto:krishnakantsilawat2006@gmail.com" className="text-gray-500 hover:text-violet-400 transition-colors">Email</a>
          </div>
          <p className="text-gray-600 text-xs">© 2025 Krishankant Silawat. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function SectionHeader({ icon, title }: { icon: string; title: string }) {
  return (
    <div className="flex items-center gap-4">
      <span className="text-2xl">{icon}</span>
      <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">{title}</h2>
      <div className="flex-1 h-px bg-gradient-to-r from-violet-500/40 to-transparent" />
    </div>
  );
}
